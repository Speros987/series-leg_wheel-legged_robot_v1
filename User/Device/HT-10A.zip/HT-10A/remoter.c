#include "remoter.h"


uint8_t Rx_Data[BUFF_SIZE];

DMA_HandleTypeDef hdma_uart3_rx;

int Remoter_disconnected_times;
uint8_t Error_state = 0;

SBUS_CH_Struct SBUS_CH;
HT_10A_Def HT_10A;

//Ŀǰû��ģʽ�ı�˲��
void Sbus_Data_Count(uint8_t *buf)
{
    if (buf[23] == 0 && buf[0] == 0x0F)
    {
		Remoter_disconnected_times = 0;
        SBUS_CH.ConnectState = 1;
        SBUS_CH.CH1 = ((int16_t)buf[ 1] >> 0 | ((int16_t)buf[ 2] << 8 )) & 0x07FF;
        SBUS_CH.CH2 = ((int16_t)buf[ 2] >> 3 | ((int16_t)buf[ 3] << 5 )) & 0x07FF;
        SBUS_CH.CH3 = ((int16_t)buf[ 3] >> 6 | ((int16_t)buf[ 4] << 2 ) | (int16_t)buf[ 5] << 10 ) & 0x07FF;
        SBUS_CH.CH4 = ((int16_t)buf[ 5] >> 1 | ((int16_t)buf[ 6] << 7 )) & 0x07FF;
        SBUS_CH.CH5 = ((int16_t)buf[ 6] >> 4 | ((int16_t)buf[ 7] << 4 )) & 0x07FF;
        SBUS_CH.CH6 = ((int16_t)buf[ 7] >> 7 | ((int16_t)buf[ 8] << 1 ) | (int16_t)buf[9] << 9 ) & 0x07FF;
        SBUS_CH.CH7 = ((int16_t)buf[ 9] >> 2 | ((int16_t)buf[10] << 6 )) & 0x07FF;
        SBUS_CH.CH8 = ((int16_t)buf[10] >> 5 | ((int16_t)buf[11] << 3 )) & 0x07FF;
        SBUS_CH.CH9 = ((int16_t)buf[12] << 0 | ((int16_t)buf[13] << 8 )) & 0x07FF;
        SBUS_CH.CH10 = ((int16_t)buf[13] >> 3 | ((int16_t)buf[14] << 5 )) & 0x07FF;
        SBUS_CH.CH11 = ((int16_t)buf[14] >> 6 | ((int16_t)buf[15] << 2 ) | (int16_t)buf[16] << 10 ) & 0x07FF;
        SBUS_CH.CH12 = ((int16_t)buf[16] >> 1 | ((int16_t)buf[17] << 7 )) & 0x07FF;
        SBUS_CH.CH13 = ((int16_t)buf[17] >> 4 | ((int16_t)buf[18] << 4 )) & 0x07FF;
        SBUS_CH.CH14 = ((int16_t)buf[18] >> 7 | ((int16_t)buf[19] << 1 ) | (int16_t)buf[20] << 9 ) & 0x07FF;
        SBUS_CH.CH15 = ((int16_t)buf[20] >> 2 | ((int16_t)buf[21] << 6 )) & 0x07FF;
        SBUS_CH.CH16 = ((int16_t)buf[21] >> 5 | ((int16_t)buf[22] << 3 )) & 0x07FF;

    	HT_10A.left_x = (float)(SBUS_CH.CH4 - 992) / 800 ;
    	HT_10A.left_y = (float)(SBUS_CH.CH3 - 992) / 800 ;
    	HT_10A.right_x = (float)(SBUS_CH.CH1 - 992) / 800 ;
    	HT_10A.right_y = (float)(SBUS_CH.CH2 - 992) / 800 ;
    	switch (SBUS_CH.CH5)
    	{
    		case 192:
    			HT_10A.switch_left_3 = shang_3;
    			break;
    		case 992:
    			HT_10A.switch_left_3 = zhong_3;
    			break;
    		case 1792:
    			HT_10A.switch_left_3 = xia_3;
    			break;
    		default:
    			HT_10A.switch_left_3 = error_3;
    			break;
    	}
    	switch (SBUS_CH.CH6)
    	{
    		case 192:
    			HT_10A.switch_left_2 = shang_2;
    			break;
    		case 1792:
    			HT_10A.switch_left_2 = xia_2;
    			break;
    		default:
    			HT_10A.switch_left_2 = error_2;
    			break;
    	}
    	switch (SBUS_CH.CH7)
    	{
    		case 192:
    			HT_10A.switch_right_2 = shang_2;
    			break;
    		case 1792:
    			HT_10A.switch_right_2 = xia_2;
    			break;
    		default:
    			HT_10A.switch_right_2 = error_2;
    			break;
    	}
    	switch (SBUS_CH.CH8)
    	{
    		case 192:
    			HT_10A.switch_right_3 = shang_3;
    			break;
    		case 992:
    			HT_10A.switch_right_3 = zhong_3;
    			break;
    		case 1792:
    			HT_10A.switch_right_3 = xia_3;
    			break;
    		default:
    			HT_10A.switch_right_3 = error_3;
    			break;
    	}
    	HT_10A.left_knob = SBUS_CH.CH9 - 192;
    	HT_10A.right_knob = SBUS_CH.CH10 - 192;
    }
    else
    {
		Remoter_disconnected_times ++;
		if(Remoter_disconnected_times >= 50)
      	SBUS_CH.ConnectState = 0;
    }
}

float accelarattion = 0.001f;
void contral_code()
{
	if (SBUS_CH.ConnectState == 0 || HT_10A.switch_left_2 == error_2 || HT_10A.switch_left_2 == shang_2)
	{
		manual_state = manual_error;
	}
	else
	{
		manual_state = manual_OK;
	}
	if (HT_10A.switch_left_3 == shang_3 )
	{
		task1 = 1;
	}
	if (HT_10A.switch_left_3 == xia_3 )
	{
		task1 = 3;
	}
	if (HT_10A.switch_right_2 == xia_2)
	{
		output_test2 = 5 ;
	}
	if (HT_10A.switch_right_2 == shang_2)
	{
		output_test2 = 4 ;
	}
	 x.x_target += HT_10A.left_y * accelarattion ;
	x.d_x_target = HT_10A.left_y * 0.01f ;
	target_yaw += HT_10A.left_x * accelarattion ;
}


void Remoter_Init()
{
		SBUS_CH.CH1 = 992;
		SBUS_CH.CH2 = 992;
		SBUS_CH.CH3 = 992;
		SBUS_CH.CH4 = 992;
		SBUS_CH.CH5 = 992;
		SBUS_CH.CH6 = 192;
		SBUS_CH.CH7 = 1792;
		SBUS_CH.CH8 = 992;
		SBUS_CH.CH9 = 192;
		SBUS_CH.CH10 = 992;
		SBUS_CH.SW3 = 1;
	
		Error_state = 0;
		
		HAL_UARTEx_ReceiveToIdle_DMA(&huart3, Rx_Data, BUFF_SIZE);
		__HAL_DMA_DISABLE_IT(&hdma_uart3_rx, DMA_IT_HT);
}

//�°嵥������ң��������
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	if(huart->Instance == USART3)
	{
		// ������Ϻ�����
		HAL_UART_Transmit_DMA(&huart6, Rx_Data, Size);
		Sbus_Data_Count(Rx_Data);
		HAL_UARTEx_ReceiveToIdle_DMA(&huart3, Rx_Data, BUFF_SIZE);
		contral_code();
	}
	if(huart->Instance == USART6)
	{
		HAL_UARTEx_ReceiveToIdle_DMA(&huart6, up_board_data, 128);
	}
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef * huart)
{
	if(huart->Instance == USART3)
	{
		__HAL_UNLOCK(huart);
		memset(Rx_Data, 0, BUFF_SIZE);							   // ������ջ���		
		HAL_UARTEx_ReceiveToIdle_DMA(&huart3, Rx_Data, BUFF_SIZE);// ���շ������������
	}
}
